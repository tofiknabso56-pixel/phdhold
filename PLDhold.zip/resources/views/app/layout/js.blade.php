<script src="{{asset('public/footbal')}}/assets/js/jquery-3.7.0.min.js"></script>
<script src="{{asset('public/footbal')}}/assets/js/owl.carousel.min.js"></script>
<script src="{{asset('public/footbal')}}/assets/js/script.js"></script>
